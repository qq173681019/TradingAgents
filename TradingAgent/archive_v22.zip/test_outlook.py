#!/usr/bin/env python3
"""快速测试大盘预判避险机制"""
from daily_recommender import _market_outlook_check

# Test case 1: normal market
result = _market_outlook_check({'risk_level': 3, 'momentum': 0.5, 'regime': 'range'})
print(f"Test1 (normal): risk={result['risk_level']}, skip={result['should_skip']}, pos={result['position_advice']}")

# Test case 2: dangerous - risk 4 + negative momentum
result = _market_outlook_check({'risk_level': 4, 'momentum': -1.5, 'regime': 'bear'})
print(f"Test2 (r4 neg): risk={result['risk_level']}, skip={result['should_skip']}, pos={result['position_advice']}")

# Test case 3: extreme - risk 5
result = _market_outlook_check({'risk_level': 5, 'momentum': -3.0, 'regime': 'bear'})
print(f"Test3 (r5): risk={result['risk_level']}, skip={result['should_skip']}, pos={result['position_advice']}")

# Test case 4: safe - risk 2
result = _market_outlook_check({'risk_level': 2, 'momentum': 1.0, 'regime': 'bull'})
print(f"Test4 (r2 bull): risk={result['risk_level']}, skip={result['should_skip']}, pos={result['position_advice']}")

print("All tests passed!")
