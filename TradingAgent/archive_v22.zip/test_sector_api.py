#!/usr/bin/env python3
"""Quick test for sector API"""
import os, requests, time

for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'

session = requests.Session()
session.trust_env = False

url = 'https://17.push2.eastmoney.com/api/qt/clist/get'
params = {
    'pn': '1', 'pz': '100', 'po': '1', 'np': '1',
    'ut': 'bd1d9ddb04089700cf9c27f6f7426281', 'fltt': '2', 'invt': '2',
    'fid': 'f3', 'fs': 'm:90+t:2+f:!50',
    'fields': 'f2,f3,f4,f8,f12,f14,f104,f105,f128,f136,f140,f141'
}

for attempt in range(3):
    try:
        r = session.get(url, params=params, timeout=15)
        data = r.json()
        items = data['data']['diff']
        print(f'Got {len(items)} sectors')
        for item in items[:10]:
            print(f"  {item['f14']}: 涨幅={item.get('f3','?')}% 换手={item.get('f8','?')}%")
        break
    except Exception as e:
        print(f'Attempt {attempt+1} failed: {type(e).__name__}: {e}')
        time.sleep(3)
