"""测试 Choice CSD 更多指标名和批量方式"""
import os, sys, json
sys.path.insert(0, r'D:\GitHub\TradingAgents\TradingShared')
sys.path.insert(0, r'D:\GitHub\TradingAgents\TradingShared\api')

from api.choice_api_wrapper import ChoiceAPIWrapper

choice = ChoiceAPIWrapper(timeout=60)

# 1. 试试不同的 MA 指标名
print("[1] 测试不同 MA 命名")
for names in ["CLOSE,MA_M5,MA_M10,MA_M20",
              "CLOSE,MA_5,MA_10,MA_20",
              "CLOSE,MA5,MA10,MA20,MA60",
              "CLOSE,SMA5,SMA10,SMA20",
              "CLOSE,AVGPC5,AVGPC10,AVGPC20"]:
    r = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09", indicators=names)
    has_data = any(v and v[0] is not None for v in r.get('data', {}).values() if isinstance(v, list))
    sample = {k: v for k, v in r.get('data', {}).items() if k != 'CLOSE'}
    print(f"  {names} -> {sample}")

# 2. 试试换手率的准确指标名
print("\n[2] 换手率指标名")
for names in ["CLOSE,TURN,TURNRATE,FREESWAP,EXCHANGE"]:
    r = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09", indicators=names)
    sample = {k: v for k, v in r.get('data', {}).items() if k != 'CLOSE'}
    print(f"  {names} -> {sample}")

# 3. 试试基本面指标
print("\n[3] 基本面指标")
for names in ["CLOSE,PE,PB,PS,DVTTM,EPS,BPS,ROE,NETPROFITMARGIN",
              "CLOSE,VOTEDCAPITAL,TOTALSHARE"]:
    r = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09", indicators=names)
    sample = {k: v for k, v in r.get('data', {}).items() if k != 'CLOSE'}
    print(f"  {names[:50]} -> {sample}")

# 4. 测试单只多日 - 60天数据
print("\n[4] 单只60天数据量")
r = choice.get_kline_data("000001.SZ", start_date="2026-02-01", end_date="2026-05-09",
                          indicators="OPEN,HIGH,LOW,CLOSE,VOLUME,TURN,CHGPCT,AMOUNT,PE,PB")
if r.get('success'):
    print(f"  days: {len(r.get('dates', []))}")
    print(f"  indicators: {r.get('indicators')}")
    pe_vals = [v for v in r['data'].get('PE', []) if v is not None]
    pb_vals = [v for v in r['data'].get('PB', []) if v is not None]
    print(f"  PE non-None: {len(pe_vals)}/{len(r.get('dates',[]))}")
    print(f"  PB non-None: {len(pb_vals)}/{len(r.get('dates',[]))}")

# 5. 每次一只，循环10只测试批量可行性和速度
print("\n[5] 逐只批量测试 (10只 x 5天)")
import time
test_codes = [
    ("000001.SZ", "平安银行"), ("600036.SH", "招商银行"), ("300750.SZ", "宁德时代"),
    ("002594.SZ", "比亚迪"), ("601012.SH", "隆基绿能"), ("688981.SH", "中芯国际"),
    ("002475.SZ", "立讯精密"), ("000977.SZ", "浪潮信息"), ("601899.SH", "紫金矿业"),
    ("600519.SH", "贵州茅台"),
]
t0 = time.time()
success = 0
for code, name in test_codes:
    r = choice.get_kline_data(code, start_date="2026-05-06", end_date="2026-05-09",
                              indicators="CLOSE,VOLUME,TURN,CHGPCT,PE,PB")
    ok = r.get('success', False)
    if ok:
        success += 1
        close = r['data'].get('CLOSE', [None])[-1]
        pe = r['data'].get('PE', [None])[-1]
        print(f"  {code} {name}: CLOSE={close}, PE={pe}")
    else:
        err = repr(r.get('error', ''))[:100]
        print(f"  {code} {name}: FAIL - {err}")
elapsed = time.time() - t0
print(f"  Success: {success}/10, Time: {elapsed:.1f}s ({elapsed/10:.2f}s/stock)")

print("\nDone")
