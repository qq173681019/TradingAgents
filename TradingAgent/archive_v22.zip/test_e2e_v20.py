"""End-to-end test: Plan A (real features) + V20 params vs V19 params"""
import os, sys
os.chdir(r'D:\GitHub\TradingAgents\TradingAgent')
sys.path.insert(0, os.path.join('..', 'TradingShared'))
sys.path.insert(0, '.')

from daily_recommender import get_v17_params_for_risk
from real_feature_calculator import RealFeatureCalculator

# Test stocks
test_stocks = [
    {'code': '002818', 'name': '富森美', 'short_term_score': 7.5, 'long_term_score': 5.0,
     'chip_score': 6.0, 'hot_sector_score': 7.0, 'turnover_rate': 3.5,
     'recent_gain': 11.3, 'beta': 1.0, 'industry': '家居用品', 'sector_change': 0.0},
    {'code': '002786', 'name': '银宝山新', 'short_term_score': 7.0, 'long_term_score': 4.5,
     'chip_score': 6.5, 'hot_sector_score': 7.5, 'turnover_rate': 8.0,
     'recent_gain': 8.0, 'beta': 1.2, 'industry': '汽车零部件', 'sector_change': 0.0},
    {'code': '603368', 'name': '柳药集团', 'short_term_score': 7.0, 'long_term_score': 6.0,
     'chip_score': 5.5, 'hot_sector_score': 6.0, 'turnover_rate': 2.0,
     'recent_gain': 3.0, 'beta': 0.8, 'industry': '医药商业', 'sector_change': 0.0},
    {'code': '000001', 'name': '平安银行', 'short_term_score': 6.0, 'long_term_score': 5.5,
     'chip_score': 5.0, 'hot_sector_score': 5.0, 'turnover_rate': 1.0,
     'recent_gain': 1.5, 'beta': 1.0, 'industry': '银行', 'sector_change': 0.0},
    {'code': '600519', 'name': '贵州茅台', 'short_term_score': 5.0, 'long_term_score': 8.0,
     'chip_score': 4.0, 'hot_sector_score': 4.0, 'turnover_rate': 0.5,
     'recent_gain': -5.7, 'beta': 0.5, 'industry': '白酒', 'sector_change': 0.0},
]

# Load real features
calc = RealFeatureCalculator()
codes = [s['code'] for s in test_stocks]
calc.load_data(codes=codes)

# Get V20 params (risk=2, bullish)
v20_params = get_v17_params_for_risk(2)
print(f'V20 params: {len(v20_params)} keys, version={v20_params.get("version","?")}')

# Import scoring functions directly
from daily_recommender import score_with_v17_risk2

print(f'\n{"="*70}')
print(f'  Plan A + V20 Params (Real Features + Additive Scoring)')
print(f'{"="*70}')
print(f'{"code":<8} {"name":<10} {"V20 score":>10} {"RSI":>6} {"r5":>7} {"vol5":>6}')
print('-'*70)

results = []
for s in test_stocks:
    code = s['code']
    name = s['name']
    
    real_sub = calc.compute_real_subscores(code, stock_data=s)
    if real_sub:
        score = score_with_v17_risk2(real_sub, v20_params)
        rsi = real_sub.get('rsi', 0)
        r5 = real_sub.get('r5', 0)
        vol5 = real_sub.get('vol5', 0)
    else:
        score = 0
        rsi = r5 = vol5 = 0
    
    results.append((code, name, score, rsi, r5, vol5))
    print(f'{code:<8} {name:<10} {score:>10.3f} {rsi:>6.1f} {r5:>+6.1f}% {vol5:>6.2f}')

# Sort by score
sorted_r = sorted(results, key=lambda x: x[2], reverse=True)
print(f'\n  Ranking:')
for i, (code, name, score, rsi, r5, vol5) in enumerate(sorted_r, 1):
    print(f'    {i}. {code} {name:<10} score={score:>8.3f}  RSI={rsi:.0f}  r5={r5:+.1f}%')
