#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Quick test for sector_rotation module"""
import os, sys
for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy','ALL_PROXY','all_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, 'D:/GitHub/TradingAgents/TradingAgent')

from importlib import reload
import sector_rotation
reload(sector_rotation)

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

print("=" * 70)
print("Test: compute_sector_metrics_from_kline")
print("=" * 70)
metrics = sector_rotation._compute_sector_metrics_from_kline()
print(f"Metrics computed: {len(metrics)} sectors")

if metrics:
    # Sort by ret_5d
    metrics.sort(key=lambda x: x['ret_5d'], reverse=True)
    print("\nTOP10 by 5d return:")
    for m in metrics[:10]:
        print(f"  {m['sector']:15s}  5d:{m['ret_5d']:+6.2f}%  20d:{m['ret_20d']:+6.2f}%  "
              f"mom:{m['momentum']:+5.2f}  up:{m['streak_up']}d  down:{m['streak_down']}d  "
              f"stocks:{m['stock_count']}")

    print("\nBOTTOM10 by 5d return:")
    for m in metrics[-10:]:
        print(f"  {m['sector']:15s}  5d:{m['ret_5d']:+6.2f}%  20d:{m['ret_20d']:+6.2f}%  "
              f"mom:{m['momentum']:+5.2f}  up:{m['streak_up']}d  down:{m['streak_down']}d  "
              f"stocks:{m['stock_count']}")

print("\n" + "=" * 70)
print("Test: fetch_sector_ranking")
print("=" * 70)
ranking = sector_rotation.fetch_sector_ranking(force_refresh=True)
print(f"Ranking: {len(ranking)} sectors")
if ranking:
    print("\nTOP10 hot sectors:")
    for r in ranking[:10]:
        print(f"  #{r['rank']:3d} {r['sector']:15s}  score:{r['score']:6.1f}  "
              f"5d:{r['ret_5d']:+6.2f}%  cat:{r.get('category','?')}")
    print("\nTOP10 cold sectors:")
    for r in ranking[-10:]:
        print(f"  #{r['rank']:3d} {r['sector']:15s}  score:{r['score']:6.1f}  "
              f"5d:{r['ret_5d']:+6.2f}%  cat:{r.get('category','?')}")

print("\n" + "=" * 70)
print("Test: score_sector_rotation")
print("=" * 70)
test_industries = ['电子', '医药', '计算机', '新能源', '钢铁', '银行']
for ind in test_industries:
    score = sector_rotation.score_sector_rotation(ind)
    details = sector_rotation.get_sector_details(ind)
    print(f"  {ind:10s}: {score:.1f}/10  rank={details.get('rank','N/A')}  "
          f"cat={details.get('category','?')}")

print("\nTest: get_hot/cold_sectors")
hot = sector_rotation.get_hot_sectors(5)
cold = sector_rotation.get_cold_sectors(5)
print(f"  HOT:  {hot}")
print(f"  COLD: {cold}")

print("\n" + "=" * 70)
print("ALL TESTS PASSED")
print("=" * 70)
