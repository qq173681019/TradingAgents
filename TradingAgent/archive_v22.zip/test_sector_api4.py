#!/usr/bin/env python3
"""Test multiple EM endpoints"""
import os, requests, time
for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'

s = requests.Session()
s.trust_env = False
s.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})

endpoints = [
    'https://17.push2.eastmoney.com',
    'https://push2.eastmoney.com', 
    'https://push2his.eastmoney.com',
    'https://datacenter-web.eastmoney.com',
    'https://push2.eastmoney.com/api/qt/clist/get',
]

for ep in endpoints:
    print(f"Testing: {ep}")
    try:
        r = s.get(ep, timeout=10)
        print(f"  OK: status={r.status_code} len={len(r.text)}")
    except Exception as e:
        print(f"  FAIL: {type(e).__name__}: {str(e)[:80]}")
    time.sleep(0.5)

# Try datacenter API for sector ranking
print("\n--- Datacenter sector ranking ---")
url = 'https://datacenter-web.eastmoney.com/api/data/v1/get'
params = {
    'reportName': 'RPT_BOARD_INDUSTRY_DAILY',
    'columns': 'ALL',
    'pageSize': '10',
    'sortColumns': 'CHANGE_RATE',
    'sortTypes': '-1',
    'source': 'WEB',
    'client': 'WEB',
}
try:
    r = s.get(url, params=params, timeout=15)
    d = r.json()
    print(f"  success={d.get('success')} code={d.get('code')}")
    result = d.get('result', {})
    data = result.get('data', [])
    print(f"  data count: {len(data)}")
    if data:
        print(f"  first: {str(data[0])[:200]}")
except Exception as e:
    print(f"  FAIL: {type(e).__name__}: {str(e)[:200]}")
