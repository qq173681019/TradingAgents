#!/usr/bin/env python3
"""Test single sector hist API"""
import os, requests, time
for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'

s = requests.Session()
s.trust_env = False
s.headers.update({'User-Agent': 'Mozilla/5.0'})

# Test 1: sector list (1 page)
url1 = 'https://17.push2.eastmoney.com/api/qt/clist/get'
params1 = {
    'pn': '1', 'pz': '10', 'po': '1', 'np': '1',
    'ut': 'bd1d9ddb04089700cf9c27f6f7426281',
    'fltt': '2', 'invt': '2', 'fid': 'f3',
    'fs': 'm:90+t:2+f:!50',
    'fields': 'f2,f3,f12,f14'
}
print("Test 1: sector list...")
try:
    r = s.get(url1, params=params1, timeout=15)
    d = r.json()
    items = d['data']['diff']
    print(f"  OK: {len(items)} items")
    # Get first sector code for hist test
    first_code = items[0]['f12']
    first_name = items[0]['f14']
    print(f"  First: {first_name} ({first_code})")
except Exception as e:
    print(f"  FAIL: {e}")
    first_code = None

time.sleep(1)

# Test 2: sector hist
if first_code:
    url2 = 'https://push2his.eastmoney.com/api/qt/stock/kline/get'
    params2 = {
        'secid': f'90.{first_code}',
        'fields1': 'f1,f2,f3,f4,f5,f6',
        'fields2': 'f51,f52,f53,f54,f55,f56,f57',
        'klt': '101', 'fqt': '1',
        'beg': '20260401', 'end': '20260506',
        'lmt': '30',
    }
    print(f"\nTest 2: sector hist ({first_name})...")
    try:
        r = s.get(url2, params=params2, timeout=15)
        d = r.json()
        klines = d['data']['klines']
        print(f"  OK: {len(klines)} klines")
        for k in klines[-5:]:
            parts = k.split(',')
            print(f"    {parts[0]} close={parts[2]} vol={parts[5]}")
    except Exception as e:
        print(f"  FAIL: {e}")

# Test 3: another sector list page
time.sleep(1)
print(f"\nTest 3: sector list page 2...")
try:
    params1['pn'] = '2'
    r = s.get(url1, params=params1, timeout=15)
    d = r.json()
    items = d['data']['diff']
    print(f"  OK: {len(items)} items")
except Exception as e:
    print(f"  FAIL: {e}")
