#!/usr/bin/env python3
"""Find working EM datacenter API for sectors"""
import os, requests, time, json
for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'

s = requests.Session()
s.trust_env = False
s.headers.update({'User-Agent': 'Mozilla/5.0'})

url = 'https://datacenter-web.eastmoney.com/api/data/v1/get'

# Try different report names
report_names = [
    'RPT_BOARD_INDUSTRY_DAILY',
    'RPT_INDUSTRY_INDEX',
    'RPT_CUSTOM_BOARD_INDUSTRY_DAILY',
]

for rn in report_names:
    params = {
        'reportName': rn,
        'columns': 'ALL',
        'pageSize': '5',
        'sortColumns': 'CHANGE_RATE',
        'sortTypes': '-1',
        'source': 'WEB',
        'client': 'WEB',
    }
    print(f"\nReport: {rn}")
    try:
        r = s.get(url, params=params, timeout=15)
        d = r.json()
        print(f"  success={d.get('success')} code={d.get('code')} msg={d.get('message','')}")
        result = d.get('result')
        if result:
            data = result.get('data', [])
            print(f"  data count: {len(data)}")
            if data:
                print(f"  keys: {list(data[0].keys())}")
                print(f"  first: {json.dumps(data[0], ensure_ascii=False)[:300]}")
    except Exception as e:
        print(f"  FAIL: {type(e).__name__}: {str(e)[:200]}")
    time.sleep(0.5)

# Try quote API (different format)
print("\n\n--- Quote center API ---")
url2 = 'https://push2.eastmoney.com/api/qt/clist/get'
for pn in range(1, 4):
    params = {
        'pn': str(pn), 'pz': '50', 'po': '1', 'np': '1',
        'ut': 'bd1d9ddb04089700cf9c27f6f7426281',
        'fltt': '2', 'invt': '2', 'fid': 'f3',
        'fs': 'm:90+t:2+f:!50',
        'fields': 'f2,f3,f12,f14'
    }
    try:
        r = s.get(url2, params=params, timeout=10)
        d = r.json()
        items = d.get('data', {}).get('diff', [])
        print(f"  Page {pn}: {len(items)} items OK")
        if items:
            print(f"    First: {items[0]['f14']} {items[0]['f3']}%")
        break  # If first page works, we're good
    except Exception as e:
        print(f"  Page {pn}: FAIL {type(e).__name__}")
        time.sleep(2)
