"""完整推荐流程测试 — 方案A vs 映射模式对比"""
import os, sys, json
os.chdir(r'D:\GitHub\TradingAgents\TradingAgent')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath('.')), 'TradingShared'))
sys.path.insert(0, '.')

from daily_recommender import (
    map_stock_to_subscores, normalize_code,
    score_with_v17_risk2, score_with_v17_risk3, score_with_v17_risk45,
    get_v17_params_for_risk, calculate_total_score,
    _market_state,
)
from real_feature_calculator import RealFeatureCalculator
from stock_screener import StockScreener
from market_state import detect_market_state
from blacklist import filter_blacklist

# 1. 检测市场状态
ms = detect_market_state()
risk = ms.get('risk_level', 3)
print(f'市场: {ms["description"]}')
print(f'Risk: {risk}')

# 2. 筛选候选股
screener = StockScreener(risk_level=risk)
candidates = screener.screen()
candidates = filter_blacklist(candidates)
print(f'候选: {len(candidates)} 只')

# 3. 加载候选股K线
top15 = candidates[:15]
codes = [s.get('code', '') for s in top15]
calc = RealFeatureCalculator()
calc.load_data(codes=codes)
print(f'K线: {len(calc.kline)} 只加载成功')

# 4. 对比评分
params = get_v17_params_for_risk(risk)
print(f'\n{"="*70}')
print(f'  TOP15 映射 vs 真实特征  (Risk={risk})')
print(f'{"="*70}')

results = []
for s in top15:
    code = s.get('code', '')
    name = s.get('name', '')
    
    # 映射评分
    mapped_sub = map_stock_to_subscores(s)
    if risk <= 2:
        ms_val = score_with_v17_risk2(mapped_sub, params)
    elif risk == 3:
        ms_val = score_with_v17_risk3(mapped_sub, params)
    else:
        ms_val = score_with_v17_risk45(mapped_sub, params)
    
    # 真实评分
    real_sub = calc.compute_real_subscores(code, stock_data=s)
    if real_sub:
        if risk <= 2:
            rs_val = score_with_v17_risk2(real_sub, params)
        elif risk == 3:
            rs_val = score_with_v17_risk3(real_sub, params)
        else:
            rs_val = score_with_v17_risk45(real_sub, params)
        mode = 'real'
    else:
        rs_val = ms_val
        mode = 'fb'
    
    results.append({
        'code': code, 'name': name,
        'mapped': ms_val, 'real': rs_val, 'mode': mode,
        'rsi': real_sub.get('rsi', 0) if real_sub else 0,
        'r5': real_sub.get('r5', 0) if real_sub else 0,
        'vol5': real_sub.get('vol5', 0) if real_sub else 0,
        'streak': real_sub.get('streak', 0) if real_sub else 0,
    })

# 映射排名
results_by_mapped = sorted(results, key=lambda x: x['mapped'], reverse=True)
print(f'\n  [映射模式排名]')
for i, r in enumerate(results_by_mapped, 1):
    print(f'    {i}. {r["code"]} {r["name"]:<10} mapped={r["mapped"]:>8.2f}  real={r["real"]:>8.2f}  RSI={r["rsi"]:.0f}  r5={r["r5"]:+.1f}%  vol={r["vol5"]:.2f}')

# 真实排名
results_by_real = sorted(results, key=lambda x: x['real'], reverse=True)
print(f'\n  [真实特征排名] ← 方案A')
for i, r in enumerate(results_by_real, 1):
    # 找到映射排名
    old_rank = next(j for j, x in enumerate(results_by_mapped) if x['code'] == r['code']) + 1
    change = old_rank - i
    arrow = f'↑{change}' if change > 0 else (f'↓{abs(change)}' if change < 0 else '-')
    print(f'    {i}. {r["code"]} {r["name"]:<10} real={r["real"]:>8.2f}  mapped={r["mapped"]:>8.2f}  RSI={r["rsi"]:.0f}  r5={r["r5"]:+.1f}%  vol={r["vol5"]:.2f}  [{arrow}]')

# 排名变化摘要
print(f'\n  排名变化最大的:')
changes = []
for i, r in enumerate(results_by_real, 1):
    old_rank = next(j for j, x in enumerate(results_by_mapped) if x['code'] == r['code']) + 1
    changes.append((old_rank - i, r['code'], r['name'], old_rank, i))
changes.sort(key=lambda x: abs(x[0]), reverse=True)
for delta, code, name, old, new in changes[:5]:
    sign = '+' if delta > 0 else ''
    print(f'    {code} {name}: #{old} → #{new} ({sign}{delta})')
