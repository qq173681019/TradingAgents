"""精简测试 — 直接用固定股票代码测试真实特征"""
import os, sys
os.chdir(r'D:\GitHub\TradingAgents\TradingAgent')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath('.')), 'TradingShared'))
sys.path.insert(0, '.')

from daily_recommender import (
    map_stock_to_subscores, normalize_code,
    score_with_v17_risk2,
    get_v17_params_for_risk,
)
from real_feature_calculator import RealFeatureCalculator

# 固定测试股票（今天推荐过的几只）
test_stocks = [
    {'code': '002818', 'name': '富森美', 'short_term_score': 7.5, 'long_term_score': 5.0,
     'chip_score': 6.0, 'hot_sector_score': 7.0, 'turnover_rate': 3.5,
     'recent_gain': 11.3, 'beta': 1.0, 'industry': '家居用品', 'sector_change': 0.0},
    {'code': '002786', 'name': '银宝山新', 'short_term_score': 7.0, 'long_term_score': 4.5,
     'chip_score': 6.5, 'hot_sector_score': 7.5, 'turnover_rate': 8.0,
     'recent_gain': 8.0, 'beta': 1.2, 'industry': '汽车零部件', 'sector_change': 0.0},
    {'code': '603368', 'name': '柳药集团', 'short_term_score': 7.0, 'long_term_score': 6.0,
     'chip_score': 5.5, 'hot_sector_score': 6.0, 'turnover_rate': 2.0,
     'recent_gain': 3.0, 'beta': 0.8, 'industry': '医药商业', 'sector_change': 0.0},
    {'code': '000001', 'name': '平安银行', 'short_term_score': 6.0, 'long_term_score': 5.5,
     'chip_score': 5.0, 'hot_sector_score': 5.0, 'turnover_rate': 1.0,
     'recent_gain': 1.5, 'beta': 1.0, 'industry': '银行', 'sector_change': 0.0},
    {'code': '600519', 'name': '贵州茅台', 'short_term_score': 5.0, 'long_term_score': 8.0,
     'chip_score': 4.0, 'hot_sector_score': 4.0, 'turnover_rate': 0.5,
     'recent_gain': -5.7, 'beta': 0.5, 'industry': '白酒', 'sector_change': 0.0},
]

codes = [s['code'] for s in test_stocks]
print(f'测试股票: {codes}')

# 加载真实K线（只加载这5只）
calc = RealFeatureCalculator()
calc.load_data(codes=codes)
print(f'K线加载: {len(calc.kline)} 只')

# 加载V19参数
params = get_v17_params_for_risk(2)  # 牛市
print(f'使用V19 Risk2参数')

# 对比评分
print(f'\n{"="*80}')
print(f'  映射模式 vs 真实特征 对比 (Risk=2 牛市)')
print(f'{"="*80}')
print(f'{"代码":<8} {"名称":<10} {"映射分":>8} {"真实分":>8} {"差异":>8} {"RSI":>6} {"r5":>7} {"vol5":>6} {"streak":>6}')
print('-'*80)

results = []
for s in test_stocks:
    code = s['code']
    name = s['name']
    
    # 映射
    mapped = map_stock_to_subscores(s)
    ms = score_with_v17_risk2(mapped, params)
    
    # 真实
    real_sub = calc.compute_real_subscores(code, stock_data=s)
    if real_sub:
        rs = score_with_v17_risk2(real_sub, params)
        rsi = real_sub.get('rsi', 0)
        r5 = real_sub.get('r5', 0)
        vol5 = real_sub.get('vol5', 0)
        streak = real_sub.get('streak', 0)
    else:
        rs = ms
        rsi = r5 = vol5 = streak = 0
    
    diff = rs - ms
    results.append((code, name, ms, rs, diff, rsi, r5, vol5, streak))
    print(f'{code:<8} {name:<10} {ms:>8.2f} {rs:>8.2f} {diff:>+8.2f} {rsi:>6.1f} {r5:>+6.1f}% {vol5:>6.2f} {streak:>6}')

# 按真实分排序
print(f'\n  按真实特征排名:')
sorted_r = sorted(results, key=lambda x: x[3], reverse=True)
for i, (code, name, ms, rs, diff, rsi, r5, vol5, streak) in enumerate(sorted_r, 1):
    print(f'    {i}. {code} {name:<10} real={rs:>7.2f}  mapped={ms:>7.2f}  RSI={rsi:.0f}  r5={r5:+.1f}%  vol={vol5:.2f}')

print(f'\n分析:')
print(f'  - 映射模式排名靠前的股票，真实特征下可能排名大幅变化')
print(f'  - 这解释了实盘胜率(25%)远低于回测(86.2%)的根因')
print(f'  - 方案A修复后，推荐器选出的股票与回测评分一致')
