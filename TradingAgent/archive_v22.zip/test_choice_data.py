"""测试 Choice 数据能力 - 看看 CSD 能拿到哪些有用数据"""
import os, sys, json, time
sys.path.insert(0, r'D:\GitHub\TradingAgents\TradingShared')
sys.path.insert(0, r'D:\GitHub\TradingAgents\TradingShared\api')

from api.choice_api_wrapper import ChoiceAPIWrapper

choice = ChoiceAPIWrapper(timeout=60)

# 1. 基础K线 - 已知可用
print("=" * 60)
print("[1] 基础K线 (CSD) - OHLCV")
print("=" * 60)
r = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09",
                          indicators="OPEN,HIGH,LOW,CLOSE,VOLUME")
print(f"  success: {r.get('success')}")
if r.get('success'):
    print(f"  dates: {r.get('dates')}")
    print(f"  data: {r.get('data')}")

# 2. 扩展指标 - 换手率、涨跌幅、成交额
print("\n" + "=" * 60)
print("[2] 扩展K线 - TURN, CHGPCT, AMOUNT")
print("=" * 60)
r2 = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09",
                           indicators="OPEN,HIGH,LOW,CLOSE,VOLUME,TURN,CHGPCT,AMOUNT")
print(f"  success: {r2.get('success')}")
if r2.get('success'):
    print(f"  indicators: {r2.get('indicators')}")
    print(f"  data keys: {list(r2.get('data', {}).keys())}")

# 3. 更多技术指标 - MA, RSI, MACD, BOLL
print("\n" + "=" * 60)
print("[3] 技术指标 - MA, RSI, MACD, BOLL")
print("=" * 60)
r3 = choice.get_kline_data("000001.SZ", start_date="2026-04-01", end_date="2026-05-09",
                           indicators="CLOSE,MA5,MA10,MA20,MA60,RSI,MACD,BOLL")
print(f"  success: {r3.get('success')}")
if r3.get('success'):
    print(f"  indicators: {r3.get('indicators')}")
    print(f"  dates: {r3.get('dates')}")
    for ind in r3.get('indicators', []):
        vals = r3['data'].get(ind, [])
        print(f"  {ind}: {vals[-5:] if len(vals) >= 5 else vals}")
else:
    print(f"  error: {repr(r3.get('error', ''))[:200]}")

# 4. 资金流向指标
print("\n" + "=" * 60)
print("[4] 资金流向 - MF_FLOW, MF_NETAMOUNT")
print("=" * 60)
r4 = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09",
                           indicators="CLOSE,MF_NETAMOUNT,MF_FLOWIN,MF_FLOWOUT")
print(f"  success: {r4.get('success')}")
if r4.get('success'):
    for ind in r4.get('indicators', []):
        vals = r4['data'].get(ind, [])
        print(f"  {ind}: {vals}")
else:
    print(f"  error: {repr(r4.get('error', ''))[:200]}")

# 5. 估值指标 - PE, PB, PS, DVTTM
print("\n" + "=" * 60)
print("[5] 估值指标 - PE, PB, PS, 总市值")
print("=" * 60)
r5 = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09",
                           indicators="CLOSE,PE,PB,PS,TOTALMV,NEGOTIABLEMV")
print(f"  success: {r5.get('success')}")
if r5.get('success'):
    for ind in r5.get('indicators', []):
        vals = r5['data'].get(ind, [])
        print(f"  {ind}: {vals}")
else:
    print(f"  error: {repr(r5.get('error', ''))[:200]}")

# 6. 龙虎榜/大宗交易相关
print("\n" + "=" * 60)
print("[6] 其他 - 机构净买入, 融资融券")
print("=" * 60)
r6 = choice.get_kline_data("000001.SZ", start_date="2026-05-06", end_date="2026-05-09",
                           indicators="CLOSE,CRF_INSTITUTIONBUY,CRF_INSTITUTIONSELL,MARGIN_BUYVOL,SHORTSELLVOL")
print(f"  success: {r6.get('success')}")
if r6.get('success'):
    for ind in r6.get('indicators', []):
        vals = r6['data'].get(ind, [])
        print(f"  {ind}: {vals}")
else:
    print(f"  error: {repr(r6.get('error', ''))[:200]}")

# 7. 批量测试 - 多只股票
print("\n" + "=" * 60)
print("[7] 批量K线 - 10只股票")
print("=" * 60)
codes = ["000001.SZ", "600036.SH", "300750.SZ", "002594.SZ", "601012.SH",
         "688981.SH", "002475.SZ", "000977.SZ", "601899.SH", "600519.SH"]
codes_str = ",".join(codes)
r7 = choice.get_kline_data(codes_str, start_date="2026-05-08", end_date="2026-05-09",
                           indicators="CLOSE,VOLUME,TURN,CHGPCT")
print(f"  success: {r7.get('success')}")
if r7.get('success'):
    print(f"  stock_code keys: {list(r7.get('data', {}).keys())[:5]}...")
    for code in codes[:3]:
        cd = r7['data'].get(code, {})
        print(f"  {code}: {cd}")

print("\n" + "=" * 60)
print("测试完成")
print("=" * 60)
