import os, sys
os.chdir(r'D:\GitHub\TradingAgents\TradingAgent')
sys.path.insert(0, os.path.join('..', 'TradingShared'))
from daily_recommender import load_v20_params, get_v17_params_for_risk

p = load_v20_params()
print('V20 params loaded:', bool(p))
print('  r2:', len(p.get('r2', {})), 'keys')
print('  r3:', len(p.get('r3', {})), 'keys')
print('  r45:', len(p.get('r45', {})), 'keys')

for risk in [2, 3, 4, 5]:
    params = get_v17_params_for_risk(risk)
    additive = sum(1 for k in params if k.startswith('b_') or k.startswith('p_'))
    print(f'  risk={risk}: {len(params)} params, additive_terms={additive}')
