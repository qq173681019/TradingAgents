"""方案A集成测试 — 对比映射模式 vs 真实特征模式"""
import os, sys, json
os.chdir(r'D:\GitHub\TradingAgents\TradingAgent')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath('.')), 'TradingShared'))
sys.path.insert(0, '.')

from daily_recommender import (
    map_stock_to_subscores, normalize_code, 
    score_with_v17_risk2, score_with_v17_risk3, score_with_v17_risk45,
    get_v17_params_for_risk,
)
from real_feature_calculator import RealFeatureCalculator
from stock_screener import StockScreener
from market_state import detect_market_state
from blacklist import filter_blacklist

print('=== 方案A集成测试 ===')

# 1. 检测市场状态
ms = detect_market_state()
desc = ms['description']
risk = ms.get('risk_level', 3)
print(f'市场状态: {desc}')
print(f'风险等级: {risk}')

# 2. 筛选候选股
screener = StockScreener(risk_level=risk)
candidates = screener.screen()
candidates = filter_blacklist(candidates)
print(f'候选股: {len(candidates)} 只')

# 3. 加载真实特征计算器
calc = RealFeatureCalculator()
calc.load_data()

# 4. 加载V19参数
params = get_v17_params_for_risk(risk)
print(f'参数组: R{risk if risk <= 3 else "45"}')

# 5. 对TOP 15候选股计算两种评分
top15 = candidates[:15]
print(f'\nTOP 15 候选股对比 (映射 vs 真实特征):')
header = f'{"代码":<8} {"名称":<10} {"映射分":>8} {"真实分":>8} {"差异":>8} {"排名变化":<8}'
print(header)
print('-' * len(header))

results = []
for s in top15:
    code = s.get('code', '')
    name = s.get('name', '')
    
    # 映射模式子分数和评分
    mapped_sub = map_stock_to_subscores(s)
    if risk <= 2:
        mapped_score = score_with_v17_risk2(mapped_sub, params)
    elif risk == 3:
        mapped_score = score_with_v17_risk3(mapped_sub, params)
    else:
        mapped_score = score_with_v17_risk45(mapped_sub, params)
    
    # 真实特征评分
    real_subscores = calc.compute_real_subscores(code, stock_data=s)
    if real_subscores:
        if risk <= 2:
            real_score = score_with_v17_risk2(real_subscores, params)
        elif risk == 3:
            real_score = score_with_v17_risk3(real_subscores, params)
        else:
            real_score = score_with_v17_risk45(real_subscores, params)
        diff = real_score - mapped_score
        results.append((code, name, mapped_score, real_score, 'real'))
    else:
        real_score = mapped_score  # fallback
        diff = 0
        results.append((code, name, mapped_score, real_score, 'fallback'))
    
    print(f'{code:<8} {name:<10} {mapped_score:>8.2f} {real_score:>8.2f} {diff:>+8.2f}')

# 按真实特征重新排序
print(f'\n--- 按真实特征重新排序 ---')
results_sorted = sorted(results, key=lambda x: x[3], reverse=True)
for i, (code, name, mscore, rscore, mode) in enumerate(results_sorted, 1):
    old_rank = next(j for j, (c, *_) in enumerate(results) if c == code) + 1
    change = old_rank - i
    arrow = f'↑{change}' if change > 0 else (f'↓{abs(change)}' if change < 0 else '-')
    print(f'  {i}. {code} {name:<10} real={rscore:.2f}  mapped={mscore:.2f}  {mode:<8} [{arrow}]')

print(f'\n测试完成!')
