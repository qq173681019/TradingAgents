#!/usr/bin/env python3
"""Test different endpoints for sector data"""
import os, requests, time

for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy']:
    os.environ.pop(k, None)
os.environ['NO_PROXY'] = '*'

session = requests.Session()
session.trust_env = False

endpoints = [
    # Eastmoney push2
    ('https://17.push2.eastmoney.com/api/qt/clist/get', {
        'pn': '1', 'pz': '10', 'po': '1', 'np': '1',
        'ut': 'bd1d9ddb04089700cf9c27f6f7426281', 'fltt': '2', 'invt': '2',
        'fid': 'f3', 'fs': 'm:90+t:2+f:!50',
        'fields': 'f2,f3,f14'
    }),
    # Eastmoney datacenter
    ('https://datacenter-web.eastmoney.com/api/data/v1/get', {
        'reportName': 'RPT_BOARD_INDUSTRY_DAILY',
        'columns': 'SECURITY_NAME,CHANGE_RATE',
        'pageSize': '10',
        'sortColumns': 'CHANGE_RATE',
        'sortTypes': '-1',
        'source': 'WEB',
        'client': 'WEB',
    }),
]

for url, params in endpoints:
    print(f"\nTesting: {url[:50]}...")
    try:
        r = session.get(url, params=params, timeout=15)
        print(f"  Status: {r.status_code}, Length: {len(r.text)}")
        if r.status_code == 200:
            try:
                j = r.json()
                print(f"  JSON keys: {list(j.keys())[:5]}")
                if 'data' in j and j['data']:
                    print(f"  Data: {str(j['data'])[:200]}")
            except:
                print(f"  Text: {r.text[:200]}")
    except Exception as e:
        print(f"  Failed: {type(e).__name__}")

# Also try akshare with session override
print("\n\nTesting akshare with monkeypatch...")
try:
    import akshare as ak
    # Monkeypatch requests
    original_get = requests.Session.get
    def patched_get(self, *args, **kwargs):
        kwargs.setdefault('timeout', 15)
        return original_get(self, *args, **kwargs)
    requests.Session.get = patched_get
    
    df = ak.stock_board_industry_name_em()
    print(f"  SUCCESS: {df.shape}")
    print(df.head(5).to_string())
except Exception as e:
    print(f"  Failed: {type(e).__name__}: {str(e)[:200]}")
finally:
    requests.Session.get = original_get
